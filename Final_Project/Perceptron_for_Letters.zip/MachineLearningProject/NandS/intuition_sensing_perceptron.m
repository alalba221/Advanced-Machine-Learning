clearvars;

T = readtable("NandS.csv");

T1 = sortrows(T, 'second');

start_S = 5989;

train_num = 500;

T_train_n = T1(1:train_num, :);
T_test_n = T1(train_num+1:start_S-1,:);

T_train_s = T1(start_S:start_S+train_num-1, :);
T_test_s = T1(start_S+train_num:end, :);

T_train = [T_train_n; T_train_s];
T_test = [T_test_n; T_test_s];

[train_rows,cols] = size(T_train);
perm = randperm(train_rows);
T_train = T_train(perm,:);

[test_rows, cols] = size(T_test);
perm = randperm(test_rows);
T_test = T_test(perm,:);

binary_col = 2;
letter_start = 5;
letter_end = 30;

train_attr = T_train(:,2);
train_values = T_train(:, letter_start:letter_end);

test_attr = T_test(:,2);
test_values = T_test(:, letter_start:letter_end);

T_train_new = [train_attr train_values];
T_test_new = [test_attr test_values];

T_train_matrix = table2array(T_train_new);
T_test_matrix = table2array(T_test_new);

train_values = T_train_matrix(:, 2:27);
train_values_Z= zscore(train_values);
test_values = T_test_matrix(:,2:27);
test_values_Z = zscore(test_values);

T_train_Z = [T_train_matrix(:,1) train_values_Z];
T_test_Z = [T_test_matrix(:,1) test_values_Z];

% bias_col = ones(train_rows,1);
% T_train_Z = [T_train_Z bias_col];
% 
% bias_col = ones(test_rows, 1);
% T_test_Z = [T_test_Z bias_col];

weights = perceptron_train(T_train_Z(:,2:end), T_train_Z(:,1), 10000);

accuracy = perceptron_test(T_test_Z(:,2:end), T_test_Z(:,1), weights);

disp(accuracy);

function w = perceptron_train(X,Y,iterations)

    w = rand(26, 1);

    for j=1:iterations

        for i = 1 : size (X, 2)
            % Compute net input
            n = w' * X(i,:)';
            % Compute output
            a = sign (n);
            % Compute error
            e = Y(i) - a;
            % Update weights and bias
            w = w + e * X(i, :)';
        end
    end

end
    
function accuracy = perceptron_test(X,Y,w)

    hits = 0;

    n = w'*X';
    
    a = sign(n);

    for i = 1:size(X,2)

        if (Y(i) == a(i))

            hits = hits + 1;

        end
   

    end

    accuracy = hits/size(X,2);

end
